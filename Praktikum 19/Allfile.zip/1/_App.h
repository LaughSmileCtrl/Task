/***************************************************************
 * Name:      _App.h
 * Purpose:   Defines Application Class
 * Author:     ()
 * Created:   2020-12-18
 * Copyright:  ()
 * License:
 **************************************************************/

#ifndef _APP_H
#define _APP_H

#include <wx/app.h>

class _App : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // _APP_H
